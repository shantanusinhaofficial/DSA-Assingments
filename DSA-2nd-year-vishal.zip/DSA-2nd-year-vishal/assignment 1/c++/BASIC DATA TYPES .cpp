#include <iostream>
#include <cstdio>
using namespace std;

int main() {
    // Complete the code.
    
    int x;
    long y;
    char z;
    float t;
    double u;
    
    
    scanf("%d %ld %c %f %lf",&x,&y,&z,&t,&u);
    printf("%d\n%ld\n%c\n%f\n%lf",x,y,z,t,u);
    
    return 0;
}
