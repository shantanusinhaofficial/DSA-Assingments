#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */   
   int a,b,c,sum;
   cin>>a>>b>>c;
   sum=a+b+c;
   cout<<sum;
      
    return 0;
}
