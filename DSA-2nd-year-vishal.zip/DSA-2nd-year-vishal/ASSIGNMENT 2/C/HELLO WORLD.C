#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() 
{

   printf("Hello, World!\n");
   printf("Welcome to C programming.");

    return 0;
}
